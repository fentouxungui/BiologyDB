The PWMS.zip file contains all of the motifs for the human TFs from the Human TFs review (Lambert et al. Cell 2018; PMID: 29425488).
The format is the same one used by the CisBP database (http://cisbp.ccbr.utoronto.ca/).

In total, 6708 motifs are referenced in the paper. Not all of them are included here:

1068 were not included because they require a paid Transfac license
43 were not included because they are from an unpublished upcoming paper from the Hughes lab.

So, the total number of motifs provided in this directory is 5597.

Questions can be directed to Matt Weirauch: Matthew.Weirauch@cchmc.org

